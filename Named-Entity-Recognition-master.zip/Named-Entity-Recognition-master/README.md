# Named Entity Recognition (NER)
Recognize named entities on Twitter with LSTMs. From the Natural Language Processing course - Coursera's Advanced Machine Learning specialization. 
